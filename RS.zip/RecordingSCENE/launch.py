import tkinter as tk
from tkinter import messagebox
import cv2
import pyautogui
import numpy as np
import threading
import random
import os

class ScreenRecorder:
    def __init__(self, output_path):
        self.output_path = output_path
        self.recording = False
        self.out = None

    def start_recording(self):
        self.recording = True
        screen_size = pyautogui.size()
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        self.out = cv2.VideoWriter(self.output_path, fourcc, 20.0, screen_size)

        while self.recording:
            img = pyautogui.screenshot()
            frame = np.array(img)
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            self.out.write(frame)

    def stop_recording(self):
        self.recording = False
        if self.out:
            self.out.release()
            self.out = None

def start_recording():
    if messagebox.askyesno('Confirmation', 'Are you sure you want to start recording?, Set an Scene if needed first!'):
        start_button.config(state=tk.DISABLED)
        stop_button.config(state=tk.NORMAL)
        global recorder_thread
        recorder_thread = threading.Thread(target=recorder.start_recording)
        recorder_thread.start()
        messagebox.showinfo("Info", "Recording started")

def stop_recording():
    if messagebox.askyesno('Confirmation', 'Are you sure you want to stop recording?, You may show other stuff aswell!'):
        start_button.config(state=tk.NORMAL)
        stop_button.config(state=tk.DISABLED)
        recorder.stop_recording()
        recorder_thread.join()
        messagebox.showinfo("Info", "Recording stopped and saved")

output_path = fr"C:/Users/{os.getlogin()}/Desktop/RecordingSCENE/records/recording{random.randint(1, 999999)}_{random.randint(1, 999999)}{random.randint(1, 999999)}_scene.mp4"
recorder = ScreenRecorder(output_path)

root = tk.Tk()
root.title("RecordingSCENE")
root.configure(bg="lightblue")
root.geometry("300x200")
root.resizable(False, False)

start_button = tk.Button(root, text="Start Recording", command=start_recording)
start_button.pack(pady=10)

stop_button = tk.Button(root, text="Stop Recording", command=stop_recording)
stop_button.pack(pady=10)
stop_button.config(state=tk.DISABLED)

root.mainloop()