from flask import Flask, render_template, send_from_directory
import tkinter
from tkinter import messagebox
import socket
import os

ipv4 = socket.gethostbyname(socket.gethostname())

def run():
    files = os.listdir(fr'C:/Users/{os.getlogin()}/Desktop/WebOServer/templates')
    code = codeBox.get('1.0', 'end')
    statusLabel.config(text='Status: Writing code')
    with open(fr'C:/Users/{os.getlogin()}/Desktop/WebOServer/templates/index.html', 'w') as file:
        file.write(code)
    statusLabel.config(text='Status: Ready')
    messagebox.showinfo('Info', f'Server will be run in http://{ipv4}:5000')
    app = Flask(__name__)

    @app.route('/')
    def index():
        return render_template('index.html')
    
    for file in files:
        if file.endswith('.html'):
            app.add_url_rule(f'/{file}', file, lambda file=file: render_template(file))
        else:
            file_directory = os.path.join(os.getcwd(), 'downloablefiles')
            os.rename(fr'templates/{file}', fr'downloablefiles/{file}')
            app.add_url_rule(f'/{file}', file, lambda file=file: send_from_directory(file_directory, file, as_attachment=True))

    if __name__ == '__main__':
        app.run(host='0.0.0.0', port=5000)

def lookup():
    import webview
    webview.create_window('HTML Lookup', html=codeBox.get('1.0', 'end'))
    webview.start()

def addfile():
    fileadder = tkinter.Tk()
    fileadder.title('Add File')
    fileadder.geometry('400x400')
    fileadder.resizable(False, False)
    fileadder.configure(bg='white')
    fileentry = tkinter.Entry(fileadder, bg='gray', fg='white', font=('Arial', 12))
    fileentry.pack()
    entrylabel = tkinter.Label(fileadder, text='Enter file name and format', bg='white', font=('Arial', 12))
    entrylabel.pack()
    
    def addspecificfile():
        with open(fr'C:/Users/{os.getlogin()}/Desktop/WebOServer/templates/{fileentry.get()}', 'w') as file:
            file.write('')
        messagebox.showinfo('Info', f'File {fileentry.get()} added')
        fileeditor = tkinter.Tk()
        fileeditor.title(f'File Editor - {fileentry.get()}')
        filename = fileentry.get()
        fileeditor.geometry('800x650')
        fileeditor.resizable(False, False)
        fileeditor.configure(bg='white')
        filecodeBox = tkinter.Text(fileeditor, bg='gray', fg='white', font=('Arial', 12), width=97, height=30)
        filecodeBox.pack()
        
        def save():
            with open(fr'C:/Users/{os.getlogin()}/Desktop/WebOServer/templates/{filename}', 'w') as file:
                file.write(filecodeBox.get('1.0', 'end'))
            messagebox.showinfo('Info', f'File {filename} saved')
        
        SaveButton = tkinter.Button(fileeditor, text='Save', bg='black', fg='white', font=('Arial', 12), command=save)
        SaveButton.pack()
        fileadder.destroy()
    
    fileButton = tkinter.Button(fileadder, text='Add File', bg='black', fg='white', font=('Arial', 12), command=addspecificfile)
    fileButton.pack()
    fileadder.mainloop()

rootEditor = tkinter.Tk()
rootEditor.title('HTML Editor')
rootEditor.geometry('800x650')
rootEditor.resizable(False, False)
rootEditor.configure(bg='white')
codeBox = tkinter.Text(rootEditor, bg='gray', fg='white', font=('Arial', 12), width=97, height=30)
codeBox.pack()
runButton = tkinter.Button(rootEditor, text='Run', bg='black', fg='white', font=('Arial', 12), command=run)
runButton.pack()
lookUpButton = tkinter.Button(rootEditor, text='Look Up Website', bg='black', fg='white', font=('Arial', 12), command=lookup)
lookUpButton.pack()
addFileButton = tkinter.Button(rootEditor, text='Add File', bg='black', fg='white', font=('Arial', 12), command=addfile)
addFileButton.pack()
statusLabel = tkinter.Label(rootEditor, text='Status: Off', bg='white', font=('Arial', 12))
statusLabel.pack()
rootEditor.mainloop()