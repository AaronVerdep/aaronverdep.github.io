import tkinter as tk
from tkinter import scrolledtext, messagebox, Text, Frame, Button
from tkinter import simpledialog, BooleanVar, Checkbutton, filedialog
import subprocess
import os
import re

class LineNumberedText(Text):
    def __init__(self, master, **kwargs):
        self.frame = Frame(master)
        self.line_numbers = Text(self.frame, width=4, padx=3, takefocus=0, border=0, background='lightgray', state='disabled', wrap='none')
        self.line_numbers.pack(side='left', fill='y')
        Text.__init__(self, self.frame, **kwargs)
        self.pack(side='right', fill='both', expand=True)
        self.yscrollcommand = self._scroll_both
        self.bind('<KeyRelease>', self._update_line_numbers)
        self.bind('<MouseWheel>', self._update_line_numbers)
        self._orig = Text.count
        self._update_line_numbers()
    
    def _scroll_both(self, *args):
        self.line_numbers.yview_moveto(args[0])
        self.yview_moveto(args[0])
    
    def count(self, index1, index2=None, *args):
        if args and args[0] == 'lines':
            return (len(self.get(index1, index2).split('\n')),)
        elif args and args[0] == 'chars':
            return (len(self.get(index1, index2)),)
        else:
            return self._orig(self, index1, index2, *args)
    
    def _update_line_numbers(self, event=None):
        self.line_numbers.config(state='normal')
        self.line_numbers.delete('1.0', 'end')
        num_lines = self.count('1.0', 'end', 'lines')[0]
        for i in range(1, int(num_lines)):
            self.line_numbers.insert(f"{i}.0", f"{i:3d}\n")
        self.line_numbers.config(state='disabled')

class OSEditorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("OS Bootloader Editor")
        self.root.geometry("800x600")
        
        self.main_frame = tk.Frame(root)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.editor = LineNumberedText(self.main_frame, wrap=tk.NONE, font=("Courier New", 12), undo=True)
        self.editor.frame.pack(fill=tk.BOTH, expand=True)
        
        self.button_frame = tk.Frame(self.main_frame)
        self.button_frame.pack(fill=tk.X, pady=10)
        
        self.create_button = tk.Button(self.button_frame, text="Create Bootloader", command=self.create_bootloader, width=15, height=2)
        self.create_button.pack(side=tk.LEFT, padx=5)
        
        self.exit_button = tk.Button(self.button_frame, text="Exit", command=self.exit_app, width=8, height=2)
        self.exit_button.pack(side=tk.RIGHT, padx=5)
    
    def create_bootloader(self):
        try:
            content = self.editor.get("1.0", tk.END)
            os_name = simpledialog.askstring("OS Name", "Enter a name for your OS:", initialvalue="MyOS")
            if not os_name:
                messagebox.showinfo("Cancelled", "Bootloader creation cancelled.")
                return
            
            safe_name = re.sub(r'[^a-zA-Z0-9_]', '_', os_name)
            asm_file = f"{safe_name}.asm"
            img_file = f"{safe_name}.img"
            
            with open(asm_file, "w") as f:
                f.write(content)
            
            subprocess.run(["nasm", "-f", "bin", asm_file, "-o", img_file], check=True)
            
            # Eliminar el archivo .asm después de compilar
            if os.path.exists(asm_file):
                os.remove(asm_file)
            
            messagebox.showinfo("Success", f"{os_name} bootloader creado con éxito como {img_file}!")
            
            run_qemu = messagebox.askyesno("Ejecutar en QEMU", "¿Quieres probarlo en QEMU?")
            
            if run_qemu:
                subprocess.run(["qemu-system-x86_64", "-fda", img_file])
        
        except subprocess.CalledProcessError as e:
            messagebox.showerror("Error", f"Error creando el bootloader:\n{e.stderr}")
        except Exception as e:
            messagebox.showerror("Error", f"Error creando el bootloader: {str(e)}")
    
    def exit_app(self):
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = OSEditorGUI(root)
    root.mainloop()

