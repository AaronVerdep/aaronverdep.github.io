from flask import Flask, render_template, send_from_directory
import os
import sys
import random

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

app = Flask(__name__)
subdomains = os.listdir('templates')
downloables = os.listdir('downloable')

@app.route('/')
def index():
    return render_template('index.html')

for subdomain in subdomains:
    print(f'Adding route for subdomain /{subdomain}')
    @app.route(f'/{subdomain}')
    def subdomain_route():
        return render_template(f'{subdomain}.html')

for downloadable in downloables:
    print(f'Adding route for downloadable {downloadable} in /source/{downloadable}')
    @app.route(f'/source/{downloadable}')
    def download_route(downloadable=downloadable):
        return send_from_directory('downloable', downloadable, is_attachement=True)
    
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=random.randint(1000, 65000))