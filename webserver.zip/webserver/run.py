
#############################################################
from flask import Flask, render_template, send_from_directory
import os
import sys
import random

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

downloadables = os.listdir('downloable')
templates = os.listdir('templates')

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

def addtemplate(filename):
    @app.route(f'/{filename}')
    def template():
        return render_template(filename)

def addsource(filename):
    @app.route(f'/source/{filename}')
    def source():
        return send_from_directory('downloable', filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=random.randint(1000, 65000))
#############################################################


#####################################################################################################################

# Add all templates to the website here using the addtemplate function, and downloables using the addsource function!

#####################################################################################################################