----------------WebServer-------------------

PLEASE READ THIS CAREFULLY.

The Website only works to those who are connected
to your Internet!

If you want to make it public, use ngrok, Serveo, or LocalTunnel!

Thanks for using WebServer!

- NotRealGuest

--------------REQUIREMENTS------------------

1 - Install Python, You can find it in the MS Store or his website (Official)

2 - With Terminal, Execute the following Commands:

> pip install Flask

3 - And open "run.py"

4 - And Done!

----------------QUESTIONS---------------------

Q - Why does "run.py" donest run?

A - Open the webserver folder with terminal, and then do "run.py", if in PowerShell, "./run.py"

----------------------------------------------